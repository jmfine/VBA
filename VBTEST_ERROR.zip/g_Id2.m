function [gx,dG_dX,dG_dPhi] = g_Id2(Xt,Phi,ut,inG)
% Identity observation mapping (partially observable)
n=size(Xt);
G = eye(n);



gx = G*Xt;
dG_dX = G';
dG_dPhi=[];

