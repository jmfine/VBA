clear variables
close all


% Choose basic settings for simulations
n_t = 1e2;
f_fname = @f_ARTest;
 g_fname = @g_Id2;

u       = [];


% Parameters of the simulation
n = 1; % # hidden states
alpha   = 1e1;
sigma=1e1;
theta   = [0.5];
phi     = [];
x0 = zeros(n,1);

% Build priors for model inversion

priors.muX0 = zeros(n,1);
priors.SigmaX0 = 1e0*eye(n);
priors.muTheta = 1*ones(1,1);
priors.SigmaTheta = 1e0*eye(1);
priors.a_alpha = 1e0;
priors.b_alpha = 1e0;
priors.a_sigma = 1e0;
priors.b_sigma = 1e0;% 
% % Build options and dim structures for model inversion
 options.priors      = priors;
% options.inG.bias   = randn(4,1);
% options.backwardLag  = 4;
options.binomial = 0;
dim.n_theta         = 1;
dim.n_phi           = [];
dim.n               = n;
% options.checkGrads = 1;

% Build time series of hidden states and observations
[y,x,x0,eta,e] = simulateNLSS(n_t,f_fname,g_fname,theta,phi,u,alpha,sigma,options,x0);

displaySimulations(y,x,eta,e)
% disp('--paused--')

[posterior,out] = VBA_NLStateSpaceModel(y,u,f_fname,g_fname,dim,options);
