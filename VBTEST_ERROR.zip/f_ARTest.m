function [fx,dfdx,dfdp] = f_ARTest(x,theta,u,in)
% AR(1) evolution function

size(theta)
fx = theta(1)*x;

dfdx = theta(1);
dfdp = x;